# img2poem

- test.py

  使用样例

- config.py

  当gpus字符串为空时，使用CPU推断;

  若要使用GPU, gpus = "0,1"
